# General & practical

# **Address, route, directions and basic information**

[https://goo.gl/maps/q5tMWGjwBLv](https://goo.gl/maps/q5tMWGjwBLv)

**Address:**

Blendle HQ

Catharijnesingel 52

3511 GC Utrecht, NL

4th floor

---

**Route:**

By public transportation, from Utrecht CS trains: [https://www.youtube.com/watch?v=aWMWofU5-FA](https://www.youtube.com/watch?v=aWMWofU5-FA)

By car: park here: [http://www.interparking.nl/nl-NL/find-parking/P1 Moreelsepark/](http://www.interparking.nl/nl-NL/find-parking/P1%20Moreelsepark/) Blendle can reimburse parkings tickets for guests. 

---

**KVK (Chamber of commerce) number:**

58724109

---

**BTW (VAT) number:**

[Here](https://www.notion.so/1fbb88c6735343c8a3ba8b409ed124d4?pvs=21) (non public)

---

# **Security and access to the office**

---

[More about entry to the office](https://www.notion.so/8354943cbce846e086ad48e67dc153bc?pvs=21) (non public)

---

# Work at Blendle

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/). If you want to be kept in the loop about Blendle, you can sign up for [our behind the scenes newsletter](https://blendle.homerun.co/yes-keep-me-posted/tr/apply?token=8092d4128c306003d97dd3821bad06f2).

[Tools and tips](General%20&%20practical%20437c608f7c4e4cfeabf76af7b831a441/Tools%20and%20tips%203a39f08a1bf04e659a4d91e15bc5c8de.md)